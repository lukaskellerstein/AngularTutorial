export class Product {
    public id: string;
    public name: string;
    public state: string;
    public category: string;
    public price: number;
}