# Content

1. Smart and Dumb component

2. Usage of OnPush vs. Default

check console and "Checking the view - ProductListComponent" text
