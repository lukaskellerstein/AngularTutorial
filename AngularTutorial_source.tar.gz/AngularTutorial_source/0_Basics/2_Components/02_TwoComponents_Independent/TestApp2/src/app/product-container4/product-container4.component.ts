import { Component, OnInit, AfterViewChecked, AfterViewInit, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-container4',
  templateUrl: './product-container4.component.html',
  styleUrls: ['./product-container4.component.scss'],
  // changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProductContainer4Component implements OnInit, AfterViewInit, AfterViewChecked {

  // products$: Observable<Product[]>;

  
  constructor(private service: ProductService, private cdRef: ChangeDetectorRef) {
  }

  ngOnInit() {
    // this.products$ = this.service.products$;
  }

  ngAfterViewInit(){
    // this.products$ = this.service.productsSubject.asObservable();
  }

  ngAfterViewChecked(){
    // this.products$ = this.service.productsSubject.asObservable();
  }

}
