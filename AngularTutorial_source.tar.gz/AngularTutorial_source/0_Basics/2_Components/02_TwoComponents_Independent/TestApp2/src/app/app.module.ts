import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ProductContainerComponent } from './product-container/product-container.component';
import { ProductService } from './product.service';
import { ProductContainer2Component } from './product-container2/product-container2.component';
import { ProductContainer3Component } from './product-container3/product-container3.component';
import { ProductContainer4Component } from './product-container4/product-container4.component';
import { ProductContainer5Component } from './product-container5/product-container5.component';
import { ProductContainer6Component } from './product-container6/product-container6.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductContainerComponent,
    ProductContainer2Component,
    ProductContainer3Component,
    ProductContainer4Component,
    ProductContainer5Component,
    ProductContainer6Component
  ],
  imports: [
    BrowserModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
