import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Subject } from 'rxjs';
import { Product } from './product';
import { ProductService } from './product.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, AfterViewInit {

  // dproducts: Product[];

  constructor(private service: ProductService) {
    // this.service.productsSubject.subscribe(data => {
    //   console.log(data);
    //   this.products = <Product[]>data;
    // })

    // this.loadData();
  }

  ngOnInit(){
    // this.loadData();
  }

  ngAfterViewInit(){
    this.loadData();
  }

  loadData(){
    let products = new Array<Product>();
    products.push(<Product>{
      id: "asdf-asfd-asddf-asdfdf-fdfdf",
      name: "Product1",
      price: 100,
      description: "description of Product1"
    })

    products.push(<Product>{
      id: "wer-wer-wer-wer-werr",
      name: "Product2",
      price: 150,
      description: "description of Product2"
    })

    products.push(<Product>{
      id: "234-23-234-234-234",
      name: "Product3",
      price: 200,
      description: "description of Product3"
    })

    products.push(<Product>{
      id: "yui-yui-yu-yui-yuiu",
      name: "Product4",
      price: 250,
      description: "description of Product4"
    })

    this.service.setData(products);
  }

  addNew(){
    let product = <Product>{
      id: "1111-111-11-1-1-1-1-111",
      name: "Product111111",
      price: 10000,
      description: "description of Product1111111"
    };

    this.service.addProduct(product);

  }
}
