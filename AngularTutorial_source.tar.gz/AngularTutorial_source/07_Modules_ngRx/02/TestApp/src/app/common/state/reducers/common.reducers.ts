import { identityReducer } from "src/app/common/state/reducers/identity.reducer";

/** Main reducers */
export const commonReducers = {
    identityState: identityReducer
};
