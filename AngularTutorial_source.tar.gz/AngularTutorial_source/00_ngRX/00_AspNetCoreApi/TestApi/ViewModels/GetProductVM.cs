using System;

namespace TestApi.ViewModels
{
    public class GetProductVM
    {
        public string id { get; set; }  
    }
}