
# Steps

`ng new App1`

`cd App1`


`ng g module domain/career`
`ng g component domain/career --module domain/career`
`ng g component domain/career/navigation --module domain/career`
`ng g component domain/career/footer --module domain/career`

`ng g module domain/eshop`
`ng g component domain/eshop --module domain/eshop`
`ng g component domain/eshop/navigation --module domain/eshop`
`ng g component domain/eshop/footer --module domain/eshop`

`ng g module shared`
`ng g component shared/button --module shared`
`ng g component shared/image --module shared`

`ng g module core`

