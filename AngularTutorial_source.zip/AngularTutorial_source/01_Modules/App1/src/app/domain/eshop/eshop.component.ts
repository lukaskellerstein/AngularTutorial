import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eshop',
  templateUrl: './eshop.component.html',
  styleUrls: ['./eshop.component.css']
})
export class EshopComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
