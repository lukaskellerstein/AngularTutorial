
# Template driven forms

`ng new TestApp1 --style-scss`



# Reactive driven forms

`ng new TestApp1 --style-scss`