# Content

1. Minimal State

2. Usage of OnPush vs. Default

check console and "Checking the view - ProductListComponent" text
