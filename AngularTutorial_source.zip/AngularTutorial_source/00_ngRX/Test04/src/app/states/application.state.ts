import { Product } from "../entities/Product";

/** Global state */
export interface ApplicationState {
    firstState: FirstState;
    secondState: SecondState;
}

/** Substates */
export interface FirstState {
    lastProduct: Product;
}

export interface SecondState {
    allProducts: Product[];
}
  
