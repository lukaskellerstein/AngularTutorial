import { Action } from "@ngrx/store";
import { Product } from "../entities/Product";


export const SET_LAST_PRODUCT = '[Product] Set Last'
export class SetLastProductAction implements Action {
    readonly type = SET_LAST_PRODUCT;
    constructor(public payload: Product){}
}

export const LOAD_ALL_PRODUCTS = '[Products] Load All'
export class LoadAllProductsAction implements Action {
    readonly type = LOAD_ALL_PRODUCTS;
}

export const LOAD_ALL_PRODUCTS_SUCCESS = '[Products] Load All success';
export class LoadAllProductsSuccessAction implements Action {
    readonly type = LOAD_ALL_PRODUCTS_SUCCESS;
    constructor(public payload: Product[]){}
}

export const SAVE_PRODUCT = '[Product] Save';
export class SaveProductAction implements Action {
    readonly type = SAVE_PRODUCT;
    constructor(public payload: Product){}
}

export const DELETE_PRODUCT = '[Product] Delete';
export class DeleteProductAction implements Action {
    readonly type = DELETE_PRODUCT;
    constructor(public payload: string){}
}