using System;
using  TestApi.Models;

namespace TestApi.ViewModels
{
    public class AddProductVM
    {
        public Product item { get; set; }  
    }
}