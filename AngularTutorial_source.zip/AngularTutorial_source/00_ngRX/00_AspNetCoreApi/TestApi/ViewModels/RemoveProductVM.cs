using System;

namespace TestApi.ViewModels
{
    public class RemoveProductVM
    {
        public string id { get; set; }  
    }
}