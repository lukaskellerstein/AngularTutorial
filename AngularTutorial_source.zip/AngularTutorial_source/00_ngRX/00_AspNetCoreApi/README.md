
You can run via command 
`docker-compose up`

You can rebuild and run via command 
`docker-compose up --build` 

You can test it via Postman. Import TestApi.postman_collection.json