
# Steps 

`ng new TestNgApp`